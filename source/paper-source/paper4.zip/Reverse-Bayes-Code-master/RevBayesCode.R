## ----"COVID-Data", fig.height = 4.5-------------------------------------------
library(biostatUZH)
## install with install.packages("biostatUZH", repos = "http://R-Forge.R-project.org")

## function to format confidence intervals
myformatCI <- function (x, digits = 2, unit = "", text = "none") 
{
    x <- if (is.vector(x) && length(x) == 2L) 
        t(x)
    else as.matrix(x)
    stopifnot(is.numeric(x), ncol(x) == 2, is.character(unit), 
        is.vector(text, mode = "character"))
    if (length(text) == 1L) {
        text <- switch(text, none = c("[", ", ", "]"), german = c("von ", 
            " bis ", ""), english = c("", " to ", ""), stop("there is no predefined 'text' style \"", 
            text, "\""))
    }
    else if (length(text) != 3) {
        stop("'text' must be a single character string or of length 3")
    }
    fmtlimit <- paste0("%.", digits, "f")
    fmt <- paste0(text[1L], "$", fmtlimit, "$", "%s", text[2L], "$", fmtlimit, "$", 
        "%s", text[3L])
    sprintf(fmt, x[, 1L], unit, x[, 2L], unit)
}

## data from meta-analysis on COVID19 and corticosteroids
## -----------------------------------------------------------------------------
covidDat <- data.frame(trial = c("DEXA-COVID 19", "CoDEX", "RECOVERY",
                                 "CAPE COVID", "COVID STEROID", "REMAP-CAP",
                                 "Steroids-SARI"),
                       identifier = c("NCT04325061", "NCT04327401", "NCT04381936",
                                      "NCT02517489", "NCT04348305", "NCT02735707",
                                      "NCT04244591"),
                       drug = c(rep("Dexamethasone", 3), rep("Hydrocortisone", 3),
                                "Methylprednisolone"),
                       dose = c("High: 20 mg/d intravenously",
                                "High: 20 mg/d intravenously",
                                "Low: 6 mg/d orally or intravenously",
                                "Low: 200 mg/d intravenously",
                                "Low: 200 mg/d intravenously",
                                "Low: 50 mg every 6 h intravenously",
                                "High: 40 mg every 12 h intravenously"),
                       deathsSteroids = c(2, 69, 95, 11, 6, 26, 13),
                       nSteroids = c(7, 128, 324, 75, 15, 105, 24),
                       deathsNoSteroids = c(2, 76, 283, 20, 2, 29, 13),
                       nNoSteroids = c(12, 128, 683, 73, 14, 92, 23))
a <- covidDat$deathsSteroids
b <- covidDat$nSteroids - a
c <- covidDat$deathsNoSteroids
d <- covidDat$nNoSteroids - c
covidDat$OR <- (a/b)/(c/d)
covidDat$logOR <- log(covidDat$OR)
covidDat$logORse <- sqrt(1/a + 1/b + 1/c + 1/d)
# write.csv(x = covidDat, file = "COVID19-MA-data.csv", row.names = FALSE)

## computing some statistics
covidDat$CI95upper <- covidDat$logOR + qnorm(p = 0.975)*covidDat$logORse
covidDat$CI95lower <- covidDat$logOR - qnorm(p = 0.975)*covidDat$logORse
covidDat$t <- covidDat$logOR/covidDat$logORse
covidDat$p <- 2*pnorm(q = abs(covidDat$t), lower.tail = FALSE) # two-sided
covidDat$p1 <- pnorm(q = covidDat$t, lower.tail = TRUE) # one-sided in neg direction
covidDat$pIC <- 2*pnorm(q = abs(covidDat$t/sqrt(2)), lower.tail = FALSE) # intrinsic credibility
covidDat$CR <- covidDat$CI95lower/covidDat$CI95upper # credibility ratio

## fitting fixed-effects meta-analysis
library(metafor)
ma <- rma.uni(ai = deathsSteroids, n1i = nSteroids,
              ci = deathsNoSteroids, n2i = nNoSteroids, data = covidDat,
              measure = "OR", method = "FE")

## prior-predictive check
kp <- 1/ma$se^2 # posterior precision
mup <- unname(ma$b[,1]) # posterior mean
priorpredLS <- lapply(X = seq(1, nrow(covidDat)), FUN = function(i) {
  ## data
  k <- 1/covidDat$logORse[i]^2
  x <- covidDat$logOR[i]

  ## computing prior parameters with Reverse-Bayes
  k0 <- kp - k
  mu0 <- (kp*mup - k*x)/k0

  ## comparison: fitting FE meta-analysis on all but data but study i
  # mai <- rma.uni(ai = deathsSteroids, n1i = nSteroids,
  #                ci = deathsNoSteroids, n2i = nNoSteroids, data = covidDat[-i,],
  #                measure = "OR", method = "FE")
  # k0 <- 1/mai$se^2
  # mu0 <- unname(mai$b[,1])

  ## computing prior-predictive pvalue
  X2 <- (x - mu0)^2/(1/k + 1/k0)
  p <- pchisq(q = X2, df = 1, lower.tail = FALSE)

  data.frame("pbox" = unname(p), "k0" = k0, "mu0" = mu0, "tbox" = unname(sign(x-mu0)*sqrt(X2)))
})
priorpredDF <- do.call("rbind", priorpredLS)
covidDat <- cbind(covidDat, priorpredDF)


## ----"forest-plot-covid19", fig.height = 4.5----------------------------------
## forest plot to summarize data
## -----------------------------------------------------------------------------
forest(x = ma, slab = covidDat$trial, header = c("Trial", "logOR [95%CI]"),
       xlim = c(-10, 11),
       # texpos argument allows to change position of trial-name and trial-estimate
       # (but is undocumented in metafor::forest.rma)
       textpos = c(-10.2, 8),
       ilab = cbind(paste(covidDat$deathsSteroids, covidDat$nSteroids, sep = "/"),
                    paste(covidDat$deathsNoSteroids, covidDat$nNoSteroids, sep = "/"),
                    biostatUZH::formatPval(covidDat$p),
                    biostatUZH::formatPval(covidDat$pbox)),
       ilab.xpos = c(-6.5, -4.5, 8, 9.7), ilab.pos = 4, cex = 0.8)
text(c(-5.5, -3.3, 8.7, 10.4), 9,
     c("Steroids", "No Steroids",
       expression(italic(p)),
       expression(italic(p)["Box"])),
     cex = 0.8, font = 1)
text(-4.5, 10, c("Deaths/Patients"), cex = 0.8, font = 2)

## example recovery
indR <- which(covidDat$trial == "RECOVERY")
mu0 <- covidDat$mu0[indR]
k0 <- covidDat$k0[indR]


## ----"example1-RECOVERY"------------------------------------------------------
## illustrate meta-analytic prior-predictive check with RECOVERY trial
## -----------------------------------------------------------------------------
indR <- which(covidDat$trial == "RECOVERY")
thetaex1 <- covidDat$logOR[indR]
sigma2ex1 <- covidDat$logORse[indR]^2
tex1 <- thetaex1/sqrt(sigma2ex1)
pval <- pnorm(q = abs(tex1), lower.tail = FALSE)*2
L <- thetaex1 - qnorm(p = 0.975)*sqrt(sigma2ex1)
U <- thetaex1 + qnorm(p = 0.975)*sqrt(sigma2ex1)
S <- (U - L)^2/(4*sqrt(U*L))
za <- qnorm(p = 0.975)
tau2ex1 <- sigma2ex1/(tex1^2/za^2 - 1)


## ----"example-AnCred-MetaAnalysis", echo = FALSE------------------------------
## apply AnCred to meta-analytic estimate
U2 <- mup +qnorm(p = 0.975)*sqrt(1/kp)
L2 <- mup -qnorm(p = 0.975)*sqrt(1/kp)
S2 <-  (U2 - L2)^2/(4*sqrt(U2*L2))


## ----"Advocacy-prior-functions"-----------------------------------------------
## functions to compute advocacy prior
## -----------------------------------------------------------------------------
AL <- function(L, U){
    res <- -(U + L)/(2*U*L)*(U - L)^2
    return(res)
}

tauAL <- function(theta, t, alpha = 0.05){
    z <- qnorm(1 - alpha/2)
    res <- (2*abs(theta)/z)/(1 - t^2/z^2)
    return(res)
}


## ----"example2-REMAPCAP"------------------------------------------------------
## illustrate AnCred for non-significant results with REMAP-CAP trial
## -----------------------------------------------------------------------------
indRC <- which(covidDat$trial == "REMAP-CAP")
thetaex2 <- covidDat$logOR[indRC]
sigma2ex2 <- covidDat$logORse[indRC]^2
tex2 <- thetaex2/sqrt(sigma2ex2)
pval <- pnorm(q = abs(tex2), lower.tail = FALSE)*2

L <- thetaex2 - qnorm(p = 0.975)*sqrt(sigma2ex2)
U <- thetaex2 + qnorm(p = 0.975)*sqrt(sigma2ex2)

myAL <- AL(L, U)
tau2ex2 <- (tauAL(theta = thetaex2, t = tex2))^2


## ----"AnCred-examples-plot", fig.height = 4-----------------------------------
## illustrate both types of AnCred with plot
## -----------------------------------------------------------------------------
## significant study RECOVERY trial
pval1 <- pnorm(q = abs(tex1), lower.tail = FALSE)*2
alpha <- 0.05
za <- qnorm(p = 1 - alpha/2)
tau2 <- sigma2ex1/(tex1^2/za^2 - 1) # sufficiently sceptical prior variance
sigma2post <- 1/(1/sigma2ex1 + 1/tau2) # posterior variance
mupost <- sigma2post*thetaex1/sigma2ex1 # posterior mean

plotdf <- data.frame(x = c(2, 3, 1),
                       labelx = c("Data\n",
                                  "Posterior\n",
                                  "Sceptical\n Prior"),
                       lower = c(thetaex1 - za*sqrt(sigma2ex1),
                                 mupost - za*sqrt(sigma2post),
                                 0 - za*sqrt(tau2)),
                       mu = c(thetaex1,
                              mupost,
                              0),
                       upper = c(thetaex1 + za*sqrt(sigma2ex1),
                                 mupost + za*sqrt(sigma2post),
                                 0 + za*sqrt(tau2)),
                       col = c(1, 3, 2))
plotdf$lower <- exp(plotdf$lower)
plotdf$mu <- exp(plotdf$mu)
plotdf$upper <- exp(plotdf$upper)

par(mfrow = c(1, 2))
ylims <- c(1/2.4, 1.45)
xlims <- c(0.5, 3.5)
cex <- 1
plot(x = plotdf$x, y = plotdf$mu, pch = "",
     xlim = xlims, ylim = ylims, yaxt = "n", log = "y",
     xlab = "", ylab = "OR", xaxt = "n", las = 1,
     main = "Significant effect estimate")
axis(side = 1, at = plotdf$x, labels = plotdf$labelx, cex.axis = 0.9,
     mgp = c(3, 2, 0))
ylogTicks <- c(log(c(1/2, 1, 2)), -log(1/2)/2, log(1/2)/2)
axis(side = 2, at = exp(ylogTicks),
     labels = pCalibrate::formatBF(exp(ylogTicks)), las = 1)
abline(h = exp(ylogTicks),
       lty = 1, col = adjustcolor("lightgrey", alpha.f = 0.4))
abline(h = 1, lty = 2)
arrows(x0 = plotdf$x, x1 = plotdf$x, y0 = plotdf$mu + 0.025, y1 = plotdf$upper,
       col = plotdf$col, code = 2, angle = 90, length = 0.1, lwd = 1.5)
arrows(x0 = plotdf$x, x1 = plotdf$x, y0 = plotdf$mu - 0.025, y1 = plotdf$lower,
       col = plotdf$col, code = 2, angle = 90, length = 0.1, lwd = 1.5)
points(x = plotdf$x, y = plotdf$mu, pch = 20, cex = cex*1.5,
                 col = plotdf$col)
arrows(x0 = 2.7, x1 = 1.3, y0 = 1.28, y1 = 1.28, length = 0.05, lwd = 1.2,
       col = "#000000CC")
text(x = 2, y = 1.35, labels = "Reverse-Bayes", col = "#000000CC")
text(x = c(0.65, 0.7), y = c(plotdf$lower[3], plotdf$upper[3]),
     labels = c("-SL", "SL"), col = as.character(plotdf$col[3]))
box()

## nonsignificant study (REMAP−CAP)
## indRC <- which(covidDat$trial == "REMAP-CAP")
## theta <- covidDat$logOR[indRC]
## sigma2 <- covidDat$logORse[indRC]^2
## tex2 <- theta/sqrt(sigma2)
pval2 <- pnorm(q = abs(tex2), lower.tail = FALSE)*2
alpha <- 0.05
za <- qnorm(p = 1 - alpha/2)
tau <- (2*thetaex2/za)/(1 - tex2^2/za^2) # advocacy prior sd
tau2 <- tau^2 # advocacy prior variance
mu <- tau*za # advocacy prior mean
sigma2post <- 1/(1/sigma2ex2 + 1/tau2) # posterior variance
mupost <- sigma2post*(thetaex2/sigma2ex2 + mu/tau2) # posterior mean
plotdf2 <- data.frame(x = c(2, 3, 1),
                       labelx = c("Data\n",
                                  "Posterior\n",
                                  "Advocacy\n Prior"),
                       lower = c(thetaex2 - za*sqrt(sigma2ex2),
                                 mupost - za*sqrt(sigma2post),
                                 mu - za*sqrt(tau2)),
                       mu = c(thetaex2,
                              mupost,
                              mu),
                       upper = c(thetaex2 + za*sqrt(sigma2ex2),
                                 mupost + za*sqrt(sigma2post),
                                 mu + za*sqrt(tau2)),
                       col = c(1, 3, 4))
plotdf2$lower <- exp(plotdf2$lower)
plotdf2$mu <- exp(plotdf2$mu)
plotdf2$upper <- exp(plotdf2$upper)

ylims <- c(1/8, 2.2)
plot(x = plotdf2$x, y = plotdf2$mu, pch = "",
     xlim = xlims, ylim = ylims, yaxt = "n", log = "y",
     xlab = "", ylab = "OR", xaxt = "n", las = 1,
     main = "Non-significant effect estimate")
axis(side = 1, at = plotdf2$x, labels = plotdf2$labelx, cex.axis = 0.9,
     mgp = c(3, 2, 0), las = 1)
yaxlogTicks <- log(c(1/8, 1/4, 1/2, 1, 2))
axis(side = 2, at = exp(yaxlogTicks),
     labels = pCalibrate::formatBF(exp(yaxlogTicks)), las = 1)
abline(h = exp(yaxlogTicks), lty = 1, col = adjustcolor("lightgrey", alpha.f = 0.4))
abline(h = 1, lty = 2)
arrows(x0 = plotdf2$x, x1 = plotdf2$x, y0 = plotdf2$mu + 0.05, y1 = plotdf2$upper,
       col = plotdf2$col, code = 2, angle = 90, length = 0.1, lwd = 1.5)
arrows(x0 = plotdf2$x, x1 = plotdf2$x, y0 = plotdf2$mu - 0.05, y1 = plotdf2$lower,
       col = plotdf2$col, code = 2, angle = 90, length = 0.1, lwd = 1.5)
points(x = plotdf2$x, y = plotdf2$mu, pch = 20, cex = cex*1.5,
                 col = plotdf2$col)
arrows(x0 = 2.7, x1 = 1.3, y0 = 1.7, y1 = 1.7, length = 0.05, lwd = 1.2,
       col = "#000000CC")
text(x = 2, y = 1.9, labels = "Reverse-Bayes", col = "#000000CC")
text(x = c(0.69, 0.71), y = c(plotdf2$lower[3], plotdf2$upper[3]),
     labels = c("AL", ""), col = as.character(plotdf2$col[3]))
box()


## ----"advocacy-borrowing", fig.height = 4.5-----------------------------------
## Best et al (2021) Reverse-Bayes approach
## -----------------------------------------------------------------------------
## compute posterior median and (1 - alpha) equitailed posterior credible interval
## based on normal likelihood x|t ~ N(t, v)
## and normal mixture prior t ~ w*N(m1, v1) + (1 - w)*N(m2, v2)
library(EnvStats)
postSummaries <- function(x, v, m1, v1, m2 = 0, v2 = 4, w, alpha = 0.05) {
    ## compute precisions
    p <- 1/v
    p1 <- 1/v1
    p2 <- 1/v2

    ## marginal likelihood and posterior weights
    margLik1 <- dnorm(x, mean = m1, sd = sqrt(v1 + v))
    margLik2 <- dnorm(x, mean = m2, sd = sqrt(v2 + v))
    wPost <- w*margLik1/(w*margLik1 + (1 - w)*margLik2)

    ## parameters of posterior distribution of first component
    p1Post <- p + p1
    m1Post <- (x*p + m1*p1)/p1Post
    v1Post <- 1/p1Post

    ## parameters of posterior distribution of second component
    p2Post <- p + p2
    m2Post <- (x*p + m2*p2)/p2Post
    v2Post <- 1/p2Post

    ## compute median and credible interval limits of mixture
    res <- qnormMix(p = c(alpha/2, 0.5, 1 - alpha/2),
                    mean1 = m1Post, sd1 = sqrt(v1Post),
                    mean2 = m2Post, sd2 = sqrt(v2Post),
                    p.mix = 1 - wPost)

    names(res) <- c("lower", "median", "upper")
    return(res)
}

## function to compute weight such that posterior (1 - alpha) equitailed credible
## interval limit fixed at zero
RBweight <- function(x, v, m1, v1, m2 = 0, v2 = 4, alpha = 0.05) {
    rootFun <- function(w) {
        res <- postSummaries(x, v, m1, v1, m2, v2, w, alpha)
        if (x > 0) res[1]
        else res[3]
    }
    weight <- uniroot(f = rootFun, interval = c(0.01, 0.99))$root
    return(weight)
}

## use for RECOVERY and REMAP-CAP trial
indREC <- which(covidDat$trial == "RECOVERY")
indREM <- which(covidDat$trial == "REMAP-CAP")
x <- covidDat$logOR[indREM]
v <- covidDat$logORse[indREM]^2
m1 <- covidDat$logOR[indREC]
v1 <- covidDat$logORse[indREC]^2
wRB <- RBweight(x = x, v = v, m1 = m1, v1 = v1, m2 = 0, v2 = 4, alpha = 0.05)

wseq <- c(seq(0.001, wRB, length.out = 15), seq(wRB, 0.999, length.out = 15)[-1])
post <- t(sapply(X = wseq, FUN = function(w) {
    postSummaries(x = x, v = v, m1 = m1, v1 = v1, m2 = 0, v2 = 4, w = w,
                  alpha = 0.05)
}))
postExp <- exp(post)
postExp <- rbind(exp(cbind("lower" = x - qnorm(p = 0.975)*sqrt(v), "median" = x,
                           "upper" = x + qnorm(p = 0.975)*sqrt(v))),
                 postExp,
                 exp(cbind("lower" = m1 - qnorm(p = 0.975)*sqrt(v1), "median" = m1,
                           "upper" = m1 + qnorm(p = 0.975)*sqrt(v1))))
wseqPlot <- c(-0.2, wseq, 1.2)

par(mfrow = c(1, 1))
matplot(wseqPlot, postExp, type = "n", log = "y", las = 1, ylim = c(0.25, 2),
        xlab = "Prior weight", ylab = "OR", xaxt = "n", yaxt = "n")
axis(side = 1, seq(0, 1, length.out = 6))
axis(side = 1, c(-0.2, 1.2), labels = c("REMAP-CAP", "RECOVERY"), cex.axis = 0.95)
axis(side = 2, exp(yaxlogTicks), labels = pCalibrate::formatBF(exp(yaxlogTicks)), las = 2)
abline(h = exp(yaxlogTicks), lty = 1, col = adjustcolor("lightgrey", alpha.f = 0.4))
abline(h = 1, lty = 2)
## draw posterior credible intervals
arrows(x0 = wseq, y0 = postExp[-c(1, nrow(postExp)),1],
       col = adjustcolor(1, alpha.f = 0.2),
       y1 = postExp[-c(1, nrow(postExp)),3], code = 3, angle = 90, length = 0.05)
points(wseq, postExp[-c(1, nrow(postExp)),2], pch = 20,
       col = adjustcolor(1, alpha.f = 0.2))
## draw RECOVERY and REMAP-CAP
arrows(x0 = wseqPlot[c(1, nrow(postExp))], y0 = postExp[c(1, nrow(postExp)),1],
       y1 = postExp[c(1, nrow(postExp)),3], code = 3, angle = 90, length = 0.1,
       col = 1, lwd = 1.5)
points(wseqPlot[c(1, nrow(postExp))], postExp[c(1, nrow(postExp)),2],
       pch = 20, col = 1, cex = 1.5)
## mark posterior fixed at zero
ind <- which.min(abs(wseqPlot - wRB))
arrows(x0 = wseqPlot[ind], y0 = postExp[ind,1], y1 = postExp[ind,3], code = 3,
       angle = 90, length = 0.07, col = "darkcyan", lwd = 1.5)
points(wseqPlot[ind], postExp[ind,2], pch = 20, col = "darkcyan", cex = 1.2)
axis(side = 1, at = wRB, labels = round(wRB, 2), col.axis = "darkcyan",
     col.ticks = "darkcyan")
box()


## uncomment below to replicate Reverse-Bayes analysis from Best et al. (2021)
## ## data
## logRR.adol <- -0.3945
## SE.logRR.adol <- 0.7033
## logRR.adult <- -0.6941
## SE.logRR.adult <- 0.1303
## ## weak prior
## logRR.weak <- 0
## ## apply over a grid of weights
## SE.logRR.weak <- sqrt(12.4)
## wseq <- c(0.001, seq(0.05, 0.95, 0.05), 0.999)
## post <- t(sapply(X = wseq, FUN = function(w) {
##     postSummaries(x = logRR.adol, v = SE.logRR.adol^2, m1 = logRR.adult,
##                   v1 = SE.logRR.adult^2, m2 = 0, v2 = SE.logRR.weak^2, w = w,
##                   alpha = 0.05)
## }))
## postExp <- exp(post)
## ## determine Reverse-Bayes weight
## (wRB <- RBweight(x = logRR.adol, v = SE.logRR.adol^2, m1 = logRR.adult,
##                  v1 = SE.logRR.adult^2, m2 = 0, v2 = SE.logRR.weak^2,
##                  alpha = 0.05))
## exp(postSummaries(x = logRR.adol, v = SE.logRR.adol^2, m1 = logRR.adult,
##                   v1 = SE.logRR.adult^2, m2 = 0, v2 = SE.logRR.weak^2, w = wRB,
##                   alpha = 0.05))
## ## recreate plot
## matplot(wseq, postExp, type = "n", log = "y", ylim = c(0.0625, 4), las = 1,
##         xlab = "Prior weight", ylab = "RR")
## abline(h = 1, lty = 1, lwd = 1.5, col = adjustcolor("lightgrey", alpha.f = 0.4))
## arrows(x0 = wseq, y0 = postExp[,1], y1 = postExp[,3], code = 3, angle = 90, length = 0)
## matplot(wseq, postExp[,2], type = "p", pch = 20, col = 1, add = TRUE, log = "y")


## ----"DataPriors"-------------------------------------------------------------
## prior to data translation
## -----------------------------------------------------------------------------
scept2data <- function(tau2, rate) {
    ## function for data translation of sceptical prior to cases/non-cases:
    ## determine number of events m and number of non-events n
    ## such that Var(logOR) = 2/m + 2/n = tau2 and that m/(m + n) = rate
    n <- 2/rate/tau2
    m <- 2/tau2/(1 - rate)

    ## check that correct
    ## 2/m + 2/n

    return(c(n = n, m = m))
}

## translate sceptical prior of RECOVERY trial into data
dataREC <- covidDat[covidDat$trial == "RECOVERY",]
tau2REC <- with(dataREC, logORse^2/(t^2/qnorm(p = 0.975)^2 - 1))
rateREC <- with(dataREC, (deathsSteroids + deathsNoSteroids)/(nSteroids + nNoSteroids))
nREC <- with(dataREC, nSteroids + nNoSteroids)
resREC <- scept2data(tau2 = tau2REC, rate = rateREC)
## sqrt(sum(2/round(resREC))) ## check that approximately correct
SREC <- qnorm(p = 0.975)*sqrt(tau2REC)

adv2data <- function(tau2, controlRate, mu) {
    ## function for data translation of advocacy prior to:
    ## - cases m (equal in both arms)
    ## - non cases n1 in group 1
    ## - non cases n2 in group 2
    ## such that:
    ## Var(logOR) = 2/m + 1/n1 + 1/n2 = tau2
    ## m/(m + n2) = controlRate
    ## OR = m1*n2/(m2*n1) = n2/n1 = exp(mu)
    m <- (2*(1/controlRate - 1) + exp(mu) + 1)/tau2/(1/controlRate - 1)
    n1 <- m*(1/controlRate - 1)/exp(mu)
    n2 <- m*(1/controlRate - 1)

    ## check that correct
    ## 2/m + 1/n1 + 1/n2

    return(c(m1 = m, m2 = m, n1 = n1, n2 = n2))
}

## translate advocacy prior of REMAP-CAP trial into data
dataREM <- covidDat[covidDat$trial == "REMAP-CAP",]
muREM <- with(dataREM, 2*logOR/(1 - t^2/qnorm(p = 0.975)^2))
tau2REM <- muREM^2/qnorm(p = 0.975)^2
controlRateREM <- with(dataREM, deathsNoSteroids/nNoSteroids)
resREM <- adv2data(tau2 = tau2REM, controlRate = controlRateREM, mu = muREM)
## sqrt(sum(1/round(resREM))) ## check that approximately correct
ALREM <- muREM*2


## ----"FSN-example"------------------------------------------------------------
## illustrate equivalence of AnCred and fail-safe N using COVID meta-analysis
## -----------------------------------------------------------------------------
## fail-safe N
fsnma <- fsn(yi = covidDat$logOR, sei = covidDat$logORse, type = "Rosenberg",
             alpha = 0.05)

## sufficiently sceptical prior variance
sigma2ma <- ma$se^2
tma <- ma$zval
za <- qnorm(p = 0.975)
tau2ma <- sigma2ma/(tma^2/za^2 - 1)

## dividing sufficiently sceptical prior precision by mean precision of studies
meank <- mean(1/covidDat$logORse^2)
nAnCred <- (1/tau2ma)/meank


## ----"example-pIC"------------------------------------------------------------
## illustrate p-value for intrinsic credibility on RECOVERY and REMAP-CAP
## -----------------------------------------------------------------------------
pic1 <- 2*pnorm(q = abs(tex1)/sqrt(2), lower.tail = FALSE)
pic2 <- 2*pnorm(q = abs(tex2)/sqrt(2), lower.tail = FALSE)


## ----"AnCred-BF-examples-plot", fig.height = 4.5------------------------------
## illustrate AnCred with Bayes factors using the COVID meta-analysis data
## -----------------------------------------------------------------------------
library(lamW)
library(pCalibrate)
bfBreaks <- c(300, 100, 30, 10, 3, 1, 1/3, 1/10, 1/30, 1/100, 1/300)
bfLabels <- pCalibrate::formatBF(bfBreaks)
gsqrt <- seq(0, 5, 0.01)
bffun <- function(g, t) sqrt(1 + g)*exp(-g/(1 + g)*t^2/2)

layout(mat = matrix(c(1, 2, 3, 3), byrow = TRUE, ncol = 2), heights = c(0.9, 0.1))
## compute bf over range of g
bfAllStudies <- sapply(X = seq(1, nrow(covidDat)), FUN = function(i) {
  bffun(g = gsqrt^2, t = covidDat$t[i])
})
## compute g such that BF = 1/10
gamma <- 1/10
gRBAllStudies <- sapply(X = seq(1, nrow(covidDat)), FUN = function(i) {
  x <- -covidDat$t[i]^2*exp(-covidDat$t[i]^2)/gamma^2
  if (x > -exp(-1)) {
    gRB <- -covidDat$t[i]^2/lamW::lambertWm1(x = x) - 1
  } else gRB <- NaN
  return(gRB)
})

colsAll <- c("#000000", "#F8766D", "#00BA38", "#619CFF", "#00BFC4", "#F564E3",
             "#B79F00")
colsAll <- adjustcolor(col = colsAll, alpha.f = 0.9)
matplot(gsqrt, bfAllStudies, type = "n", log = "y", col = colsAll, las = 1,
        yaxt = "n", xaxt = "n", ylab = bquote(BF["01"]),
        xlab = bquote("Relative prior variance" ~ italic(g)),
        main = "Sceptical prior")
abline(h = bfBreaks, lty = 1, col = adjustcolor("lightgrey", alpha.f = 0.4))
abline(h = gamma, lty = 2)
matplot(gsqrt, bfAllStudies, type = "l", lty = 1, lwd = 1.2, col = colsAll,
        add = TRUE)
axis(side = 2, at = bfBreaks, labels = bfLabels, las = 1)
gsqrtbreaks <- seq(0, max(gsqrt), 1)
axis(side = 1, at = gsqrtbreaks, labels = gsqrtbreaks^2)
## draw arrow when sufficiently sceptical variance exists
for (i in seq_along(gRBAllStudies)) {
  gi <- gRBAllStudies[i]
  if (!is.nan(gi)) {
    arrows(x0 = sqrt(gi), y0 = gamma*0.9, y1 = 1/110, col = colsAll[i],
           length = 0, lty = 2)
    arrows(x0 = sqrt(gi), y0 = 1/120, y1 = 1/150, col = colsAll[i], length = 0.075)
    axis(side = 1, at = sqrt(gi), labels = round(gi, 1), col.axis = colsAll[i],
         col.ticks = colsAll[i], mgp = c(3, 0.3, 0), cex.axis = 0.6)
  }
}
box()


## Function to transform minBF to corresponding z-value
minBF2z <- function(minBF, method = "normal-local") {
  zVec <- mapply(FUN = function(minBF, method) {
    ## check that input correct
    if (!is.numeric(minBF)) stop("minBF must be numeric")
    if (minBF <= 0 | minBF > 1) stop("minBF must be in (0, 1]")
    if (!(method %in% c("normal-local", "normal-simple", "-eplogp")))
      stop('method must be either "normal-local", "normal-simple", or "-eplogp"')

    ## compute minimum z-value
    if (method == "normal-local") {
      if (minBF == 1) z <- 0
      else z <- sqrt(-lamW::lambertWm1(x = -minBF^2*exp(-1)))
    } else if (method == "normal-simple") {
      z <- sqrt(-log(minBF^2))
    } else {
      p <- exp(lamW::lambertWm1(x = -exp(-1)*minBF))
      z <- stats::qnorm(p = p/2, lower.tail = FALSE)
    }
    return(z)
  }, minBF, method)
  return(zVec)
}


## Bayes factor comparing H0: theta = 0 to H1: theta ~ N(mu, tau2)
## for effect estimate t with distribution t|theta ~ N(theta, s2)
bfmu <- function(t, s2, mu, tau2) {
  dnorm(x = t, mean = 0, sd = sqrt(s2)) / dnorm(x = t, mean = mu, sd = sqrt(s2 + tau2))
}

## Function to compute minBF over prior mean mu for effect estimate t with
## variance s2 and fixed prior coefficient of variation cv = tau/mu
minBFmu <- function(t, s2, cv) {
  ## determining extrema of BF, one of them is the minimum
  ## (first derivative has three roots, a little bit complicated ....
  ##  https://en.wikipedia.org/wiki/Cubic_equation#General_cubic_formula )
  ## cubic mu-polynomial: a*mu^3 + b*mu^2 + c*mu + d = 0
  a <- cv^4
  b <- t*cv^2
  c <- s2*cv^2 + s2 - t^2*cv^2
  d <- -t*s2
  D0 <- b^2 - 3*a*c + 0i
  D1 <- 2*b^3 - 9*a*b*c + 27*a^2*d + 0i
  C <- ((D1 + sqrt(D1^2 - 4*D0^3))/2)^(1/3)
  eps <- ((-1 + sqrt(-3 + 0i))/2)^c(0, 1, 2)
  mu <- suppressWarnings(as.double(-1/(3*a) * (b + eps*C + D0/(eps*C))))
  extrema <- bfmu(t = t, s2 = s2, mu = mu, tau2 = mu^2*cv^2)
  minInd <- which.min(extrema)
  minBF <- extrema[minInd]
  minMu <- mu[minInd]
  return(c("minMu" = minMu, "minBF" = minBF))
}

## Function to compute prior parameter mu such that resulting BF is fixed to
## cut-off gamma for specified effect estimate t with variance s2 and
## prior coefficient of variation cv = tau/mu
## -----
## different choices for cv:
## 1) level-dependent: choose cv such that if prior were an effect estimate
##    itself, the minBF would be equal to specified level gamma
##    (analogously to significance advocacy prior)
## 2) data-dependent: choose cv such that the same as the cv of the effect
##    estimate s/t
## 3) independent of anything
muAdv <- function(t, s2, gamma,
                  cv = 1/minBF2z(minBF = gamma, method = "normal-local"),
                  solution = 1) {
  ## check if there exists an advocacy prior for specified gamma
  minbf <- minBFmu(t = t, s2 = s2, cv = cv)
  if (gamma < minbf[2]) {
    warning("no advocacy prior exists for specified level")
    return(NaN)
  } else {
    rootFun <- function(mu) bfmu(t = t, s2 = s2, mu = mu, tau2 = mu^2*cv^2) - gamma
    if (sign(t) == -1) {
      if (solution == 1) int <- c(t, 0)
      else int <- c(-1000, t)
    } else {
      if (solution == 1) int <- c(0, t)
      else int <- c(t, 1000)
    }
    muA <- try(uniroot(f = rootFun, interval = int)$root)
    if (class(muA) == "try-error") return(NaN)
    return(muA)
  }
}

## Function to compute advocacy prior parameters
advPrior <- function(t, s2, gamma,
                     cv = 1/minBF2z(minBF = gamma, method = "normal-local"),
                     solution = 1) {
  mu <- muAdv(t = t, s2 = s2, gamma = gamma, cv = cv, solution = solution)
  tau2 <- mu^2*cv^2
  return(c("mu" = mu, "tau2" = tau2))
}


## compute advocacy prior for gamma = 1/3 for all studies in meta-analysis
gamma <- 1/3
# cv <- 1/minBF2z(minBF = gamma, method = "normal-local")
cv <- 1/minBF2z(minBF = gamma, method = "normal-simple")
museq <- seq(-2, 2, 0.01) # prior mean
tau2seq <- cv^2*museq^2 # prior variance
mseq <- seq(-2, 2, 0.01) # relative prior mean
advBFAllStudies <- sapply(X = seq(1, nrow(covidDat)), FUN = function(i) {
  # bfseq <- bfmu(t = covidDat$logOR[i], s2 = covidDat$logORse[i]^2,
  #               mu = museq, tau2 = tau2seq) # absolute mean
  bfseq <- bfmu(t = covidDat$logOR[i], s2 = covidDat$logORse[i]^2,
                mu = mseq*covidDat$logOR[i], tau2 = (cv*mseq*covidDat$logOR[i])^2) # relative mean
})
advMuAllStudies <- sapply(X = seq(1, nrow(covidDat)), FUN = function(i) {
  mu <- advPrior(t = covidDat$logOR[i], s2 = covidDat$logORse[i]^2, gamma = gamma)[1]
  mu/covidDat$logOR[i]
})

matplot(mseq, advBFAllStudies, type = "n", log = "y", col = colsAll, las = 1,
        yaxt = "n", xaxt = "n", ylab = bquote(BF["01"]),
        # xlab = bquote("Advocacy prior mean" ~ mu))
        xlab = bquote("Relative prior mean" ~ italic(f)),
        main = "Advocacy prior")
abline(h = bfBreaks, lty = 1, col = adjustcolor("lightgrey", alpha.f = 0.4))
abline(h = gamma, lty = 2)
matplot(mseq, advBFAllStudies, type = "l", lty = 1, lwd = 1.2, col = colsAll,
        add = TRUE)
axis(side = 2, at = bfBreaks, labels = bfLabels, las = 1)
mubreaks <- seq(-2, 2, 1)
axis(side = 1, at = mubreaks, labels = as.character(mubreaks))
# axis(side = 3, at = mubreaks, labels = round(mubreaks^2*cv^2, 1), las = 1)
# mtext(text = bquote("Advocacy prior variance" ~ tau^2), side = 3,
#       line = 2)

## draw arrow when advocacy mean exists
for (i in seq_along(advMuAllStudies)) {
  mui <- advMuAllStudies[i]
  if (!is.nan(mui)) {
    arrows(x0 = mui, y0 = gamma*0.9, y1 = 1/430, col = colsAll[i],
           length = 0, lty = 2)
    arrows(x0 = mui, y0 = 1/410, y1 = 1/480, col = colsAll[i], length = 0.075)
    axis(side = 1, at = mui, labels = round(mui, 1), col.axis = colsAll[i],
         col.ticks = colsAll[i], mgp = c(3, 0.2, 0), cex.axis = 0.6)
  }
}
box()

## draw custom legend
parbefore <- par(no.readonly = TRUE) # safe current par values
par(mar = c(0, 5, 0, 5))
plot(0:6, rep(1, 7), ylim = c(0, 2), xlim = c(-0.25, 7), type = "n", axes = FALSE,
     xlab = "", ylab = "")
segments(x0 = 0.2 + seq(0, 6), x1 = 0.8 + seq(0, 6), y0 = 1, y1 = 1,
         col = colsAll, lwd = 1.5)
text(0.5 + seq(0, 6), y = 1.4, labels = covidDat$trial, cex = 0.7)
text(-0.3, y = 1.3, labels = "Trial", font = 2)
par(parbefore)


## ----"example4-RECOVERY"------------------------------------------------------
## illustrate AnCred with Bayes factors on RECOVERY trial
## -----------------------------------------------------------------------------
gamma <- 1/10
minbfex1 <- bffun(g = tex1^2 - 1, t = tex1)
x <- -tex1^2*exp(-tex1^2)/gamma^2
gRB1 <- -tex1^2/lamW::lambertWm1(x = x) - 1
gRB2 <- -tex1^2/lamW::lambertW0(x = x) - 1

priorCI <- exp(qnorm(p = c(0.025, 0.975), mean = 0, sd = sqrt(gRB1*sigma2ex1)))

## prior to data translation
dataREC <- covidDat[covidDat$trial == "RECOVERY",]
rateREC <- with(dataREC, (deathsSteroids + deathsNoSteroids)/(nSteroids + nNoSteroids))
priordataREC <- scept2data(tau2 = gRB1*dataREC$logORse^2, rate = rateREC)


## ----"example5-RECOVERY", fig.height = 3.75-----------------------------------
## compute Bayes factor for intrinsic credibility on RECOVERY trial
## -----------------------------------------------------------------------------
indR <- which(covidDat$trial == "RECOVERY")
thetaR <- covidDat$logOR[indR]
sigma2R <- covidDat$logORse[indR]^2

## bf comparing sufficiently sceptical prior to optimistic prior
bf12 <- dnorm(x = thetaR, mean = 0, sd = sqrt((1 + gRB1)*sigma2R)) /
       dnorm(x = thetaR, mean = thetaR, sd = sqrt(2*sigma2R))

## function to compute intrinsic credibility BF
BFic <- function(th, s2, z = th/sqrt(s2)) {

    if (abs(z) < sqrt(log(2))) {
        ## BF_IC undefined in this case
        bfic <- NaN
        gss <- NaN
    } else if (abs(z) < sqrt(-2*lamW::lambertWm1(x = -exp(-1)/sqrt(2)))) {
        ## BF_IC is minBF in this case
        if (abs(z) < 1) {
            bfic <- 1
            gss <- 0
        } else {
            bfic <- abs(z)*exp(-z^2/2)*sqrt(exp(1))
            gss <- z^2 - 1
        }
    } else {
        ## BF_IC is at intersection between BF01 and BF12
        k <- lamW::lambertWm1(x = -z^2/sqrt(2)*exp(-z^2/2))
        bfic <- sqrt(-z^2/k)*exp(-(z^2 + k)/2)
        gss <- -z^2/k - 1
    }
    return((c("g" = gss, "bfi" = bfic)))
}

## compute BF_IC for recovery trial and compare to p-value for IC
bficRECOVERY <- BFic(z = tex1)
picRECOVERY <- 2*pnorm(q = abs(tex1)/sqrt(2), lower.tail = FALSE)



## how large does z need to be to have BF_IC = 1/10?
rootFun <- function(z) sapply(X = z, FUN = function(z) BFic(z = z)[2] - 1/10)
z10 <- uniroot(f = rootFun, interval = c(1, 5))$root
minBF10 <- sqrt(z10^2)*exp(-0.5*(z10^2 - 1))
pBF10 <- pnorm(q = abs(z10), lower.tail = FALSE)*2
picBF10 <- pnorm(q = abs(z10)/sqrt(2), lower.tail = FALSE)*2

## BF_IC for p = 0.05
zvalp05 <- qnorm(p = 1 - 0.05/2)
bficp05 <- BFic(z = zvalp05)[2]

## BF_IC value for pIC = 0.05
zval05 <- qnorm(p = 1 - 0.05/2)*sqrt(2)
bfic05 <- BFic(z = zval05)[2]

zBreakpoint <-  sqrt(-2*lamW::lambertWm1(x = -exp(-1)/sqrt(2)))
pICzBreakpoint <- pnorm(q = zBreakpoint/sqrt(2), lower.tail = FALSE)*2
picBks <- c(1, 0.5, round(pICzBreakpoint, 2), 0.05, 0.005, 0.0005)
zicBks <- qnorm(p = 1 -picBks/2)*sqrt(2)

## compare BFIC and pIC
zseq <- seq(0, 5, length.out = 1000)
zbks <- seq(0, 5, 1)
pICbks <- formatPval(2*pnorm(q = abs(zbks), mean = 0, sd = sqrt(2), lower.tail = FALSE))
pICs <- 2*pnorm(q = abs(zseq), mean = 0, sd = sqrt(2), lower.tail = FALSE)
bfICs <- sapply(X = zseq, FUN = function(z) BFic(z = z)[2])
minBFs <- ifelse(abs(zseq) < 1, 1, abs(zseq)*exp(-zseq^2/2)*sqrt(exp(1)))
par(mfrow = c(1, 1))
plot(zseq, y = bfICs, type = "l", log = "y",
     xlab = bquote("absolute" ~ italic(z) * "-value" ~ "|"*italic(z)*"|"),
     ylab = bquote("BF"), yaxt = "n", lwd = 1.5)
lines(zseq, minBFs, col = adjustcolor(col = 4, alpha = 0.7), lwd = 1.5, lty = 2)
axis(side = 2, at = bfBreaks, labels = bfLabels, las = 1)
abline(h = bfBreaks, lty = 1, col = adjustcolor("lightgrey", alpha.f = 0.4))
axis(side = 3, at = zicBks, labels = formatPval(picBks), las = 1)
mtext(text = bquote(italic(p)["IC"]), side = 3, line = 2)
legend("topright", c(expression("BF"["IC"]), expression("minBF"["01"])), bty = "n",
       lty = c(1, 2), col = c(1, 4), lwd = 1.5)
box()


## ----"example6-CAPE-COVID"----------------------------------------------------
## compute advocacy prior for Bayes factor AnCred with CAPE COVID trial data
## -----------------------------------------------------------------------------
indCape <- which(covidDat$trial == "CAPE COVID")
apriorCape <- advPrior(t = covidDat$logOR[indCape],
                       s2 = covidDat$logORse[indCape]^2, gamma = 1/3,
                       cv = cv)
gCape <- apriorCape[2]/covidDat$logORse[indCape]^2
mCape <- apriorCape[1]/covidDat$logOR[indCape]
myalpha <- 0.134
CapeAdvCIlogOR <- qnorm(p = c(myalpha/2, 1-myalpha/2), mean = apriorCape[1],
                        sd = sqrt(apriorCape[2]))
CapeAdvCIOR <- exp(CapeAdvCIlogOR)

aprior2Cape <- advPrior(t = covidDat$logOR[indCape],
                        s2 = covidDat$logORse[indCape]^2, gamma = 1/3,
                        cv = cv, solution = 2)
g2Cape <- aprior2Cape[2]/covidDat$logORse[indCape]^2
m2Cape <- aprior2Cape[1]/covidDat$logOR[indCape]
CapeAdv2CIlogOR <- qnorm(p = c(0.025, 0.975), mean = aprior2Cape[1],
                         sd = sqrt(aprior2Cape[2]))
CapeAdv2CIOR <- exp(CapeAdv2CIlogOR)

## prior to data translation
dataCAPE <- covidDat[covidDat$trial == "CAPE COVID",]
muCAPE <- with(dataREM, logOR*mCape)
tau2CAPE <- gCape*dataCAPE$logORse^2
controlRateCAPE <- with(dataCAPE, deathsNoSteroids/nNoSteroids)
resCAPE <- adv2data(tau2 = tau2CAPE, controlRate = controlRateCAPE, mu = muCAPE)
## sqrt(sum(1/round(resCAPE))) ## check that approximately correct


## ----"FPR-plot", fig.height = 4.5---------------------------------------------
## plot of Reverse-Bayes analysis of FPR (false positive risk)
## -----------------------------------------------------------------------------
## defining range for two-sided p-values
pseq <- exp(seq(log(0.00005), log(0.1), length.out = 200))

## computing minimum Bayes factors based on p-value and normal calibrations
minBFeplogp <- pCalibrate::pCalibrate(p = pseq, type = "exploratory")
minBFeqlogq <- pCalibrate::pCalibrate(p = pseq, type = "confirmatory")
minBFzsimple <- pCalibrate::zCalibrate(p = pseq, type = "two.sided",
                                       alternative = "simple")
minBFzlocal <- pCalibrate::zCalibrate(p = pseq, type = "two.sided",
                                      alternative = "normal")
minBFmat <- cbind("zsimple" = minBFzsimple,
                  "zlocal" = minBFzlocal,
                  "eqlogq" = minBFeqlogq,
                  "eplogp" = minBFeplogp)

## a) computing upper bound on P(H0) such that FPR = 0.05
fpr <- 0.05
pH0upper05 <- 1/(1 + (1 - fpr)/fpr*minBFmat)

## compute values at 0.05 and 0.005 to highlight in plot
phighlight <- c(0.005, 0.05)
pH0highlightS <- 1/(1 + (1 - fpr)/fpr*pCalibrate::zCalibrate(p = phighlight,
                                                             type = "two.sided",
                                                             alternative = "simple"))
pH0highlightL <- 1/(1 + (1 - fpr)/fpr*pCalibrate::zCalibrate(p = phighlight,
                                                             type = "two.sided",
                                                             alternative = "normal"))
pH0highlightq <- 1/(1 + (1 - fpr)/fpr*pCalibrate::pCalibrate(p = phighlight,
                                                             type = "confirmatory"))
pH0highlightp <- 1/(1 + (1 - fpr)/fpr*pCalibrate::pCalibrate(p = phighlight,
                                                             type = "exploratory"))
## plotting upper bound on P(H0)
par(mfrow = c(1, 2))

pbreaks <- c(0.0001, 0.0005, 0.005, 0.05, 0.5)
plabels <- c("0.0001", "0.0005", "0.005", "0.05", "0.5")
pH0breaks <- c(5, 10, 20, 50, 100)
pH0labels <- paste(pH0breaks, "%", sep = "")
cols <- c("zsimple" = "#1F78B4", "zlocal" = "#33A02C",
          "eqlogq" = "#A6CEE3", "eplogp" = "#B2DF8A")
matplot(x = pseq, y = pH0upper05*100, type = "n", lty = 1, las = 1, log = "xy",
        xaxt = "n", yaxt = "n",
        xlab = bquote(italic(p) * "-value (two-sided " * italic(z) * "-test)"),
        ylab = bquote("upper bound on Pr(" * italic(H)[0] * ")"),
        main = bquote("FPR" == 5 * "%"), axes = FALSE)
axis(side = 1, at = pbreaks[1:2], labels = plabels[1:2], cex.axis = 0.7, col = NA,
     col.ticks = 1)
axis(side = 1, at = pbreaks[3:4], labels = plabels[3:4], las = 1, col = NA,
     col.axis = "#DF536BFF", col.ticks = "#DF536BFF", cex.axis = 0.7)
axis(side = 2, at = pH0breaks, labels = pH0labels, las = 1, col = NA,
     col.ticks = 1)
abline(h = pH0breaks, lty = 1, col = adjustcolor("lightgrey", alpha.f = 0.4))
matplot(x = pseq, y = pH0upper05*100, type = "l", lty = 1, las = 1, log = "xy",
        add = TRUE, col = cols, lwd = 1.3)

## highlighting values at 0.05 and 0.005
segments(x0 = phighlight, y0 = 1e-20, y1 = pH0highlightS*100, lty = 2,
         col = "#DF536BFF")
segments(x0 = 1, x1 = phighlight, y0 = pH0highlightS*100, lty = 2,
         col = "#DF536BFF")
segments(x0 = 1, x1 = phighlight, y0 = pH0highlightL*100, lty = 2,
         col = "#DF536BFF")
axis(side = 4, at = pH0highlightS*100, mgp = c(3, 0.2, 0),
     labels = paste(round(pH0highlightS*100, 1), "%", sep = ""),
     las = 2, col = "#DF536BFF", col.axis = "#DF536BFF", tick = FALSE, cex.axis = 0.7)
axis(side = 4, at = pH0highlightL*100, mgp = c(3, 0.2, 0),
     labels = paste(round(pH0highlightL*100, 1), "%", sep = ""),
     las = 2, col = "#DF536BFF", col.axis = "#DF536BFF", tick = FALSE, cex.axis = 0.7)
## legend
leg <- c(expression(italic(z) ~ "(simple)"),
         expression(italic(z) ~ "(local)"),
         expression(- italic(e ~ q) ~ log ~ italic(q)),
         expression(- italic(e ~ p) ~ log ~ italic(p)))
legend("bottomleft", legend = leg, lty = 1, col = cols, bg = "white", lwd = 1.3,
       title = "calibration type", cex=0.8)
box()

## b) computing upper bound on P(H0) such that FPR = p-value
fpr <- pseq
pH0upperp <- 1/(1 + (1 - fpr)/fpr*minBFmat)

## compute values at 0.05 and 0.005 to highlight in plot
phighlight2 <- c(0.005, 0.05)
pH0highlight2S  <- 1/(1 + (1 - phighlight2)/phighlight2*
                       pCalibrate::zCalibrate(p = phighlight2,
                                              type = "two.sided",
                                              alternative = "simple"))
pH0highlight2L  <- 1/(1 + (1 - phighlight2)/phighlight2*
                       pCalibrate::zCalibrate(p = phighlight2,
                                              type = "two.sided",
                                              alternative = "normal"))

## plotting upper bound on P(H0)
pH0breaks2 <- c(3, 5, 10, 20, 30)
pH0labels2 <- paste(pH0breaks2, "%", sep = "")
matplot(x = pseq, y = pH0upperp*100, type = "n", lty = 1, las = 1, log = "xy",
        xaxt = "n", yaxt = "n", ylim = c(2.5, 30),
        xlab = bquote(italic(p) * "-value (two-sided " * italic(z) * "-test)"),
        ylab = bquote("upper bound on Pr(" * italic(H)[0] * ")"),
        main = bquote("FPR" == italic(p) * "-value"), axes = FALSE)
axis(side = 1, at = pbreaks[1:2], labels = plabels[1:2], cex.axis = 0.7, col = NA,
     col.ticks = 1)
axis(side = 1, at = pbreaks[3:4], labels = plabels[3:4], las = 1, col = NA,
     col.axis = "#DF536BFF", col.ticks = "#DF536BFF", cex.axis = 0.7)
axis(side = 2, at = pH0breaks2, labels = pH0labels2, las = 1, col = NA,
     col.ticks = 1)
abline(h = pH0breaks2, lty = 1, col = adjustcolor("lightgrey", alpha.f = 0.4))
matplot(x = pseq, y = pH0upperp*100, type = "l", lty = 1, las = 1, log = "xy",
        add = TRUE, col = cols, lwd = 1.3)

## highlighting values at 0.05 and 0.005
segments(x0 = phighlight2, y0 = 1e-16, y1 = pH0highlight2S*100, lty = 2,
         col = "#DF536BFF")
segments(x0 = 1, x1 = phighlight2, y0 = pH0highlight2S*100, lty = 2,
         col = "#DF536BFF")
# segments(x0 = phighlight2, y0 = 1e-16, y1 = pH0highlight2L*100, lty = 2,
#          col = "#DF536BFF")
segments(x0 = 1, x1 = phighlight2, y0 = pH0highlight2L*100, lty = 2,
         col = "#DF536BFF")
axis(side = 4, at = pH0highlight2S*100 + c(0.2, - 0.2), mgp = c(3, 0.2, 0),
     labels = paste(round(pH0highlight2S*100, 1), "%", sep = ""),
     las = 2, col = "#DF536BFF", col.axis = "#DF536BFF", tick = FALSE,
     cex.axis = 0.7)
axis(side = 4, at = pH0highlight2L*100 + c(0.2, - 0.2), mgp = c(3, 0.2, 0),
     labels = paste(round(pH0highlight2L*100, 1), "%", sep = ""),
     las = 2, col = "#DF536BFF", col.axis = "#DF536BFF", tick = FALSE,
     cex.axis = 0.7)
box()


## ----"example7-FPR-RECOVERY"--------------------------------------------------
## Reverse-Bayes analysis of FPR (false positive risk) for RECOVERY trial
## -----------------------------------------------------------------------------
pRECOVERY <- pnorm(q = abs(tex1), lower.tail = FALSE)*2
minbfRECOVERY <- -exp(1)*pRECOVERY*log(pRECOVERY)
options(scipen = 5)

pH0RECOVERY <- 1/(1 + (1 - pRECOVERY)*minbfRECOVERY/pRECOVERY)

