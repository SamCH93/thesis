# Code for *Reverse-Bayes methods for evidence assessment and research synthesis*

Repository where the R code to reproduce results from the
[paper](https://arxiv.org/abs/2102.13443) are stored.

Make sure to first install the required packages by running the following
commands in an R-session
```R
## packages on CRAN
pkgs <- c("metafor", "pCalibrate", "EnvStats", "lamW")
install.packages(pkgs)

## packages not on CRAN
install.packages("biostatUZH", repos = "http://R-Forge.R-project.org")
```

Last test on December 4 2021 on Ubuntu 20.04 with R version 4.1.2, biostatUZH
version 1.8.0, lamW version 2.1.0, EnvStats version 2.4.0, pCalibrate version
0.2-1
