
# Tweaked results

To reproduce the results from the tweaked simulations, run the following `make`
commands in this directory.

ANOVA:
```
make anova
```

ANOVA with imputation:
```
make impute
```

Estimation performance:
```
make coefs
```

Calibration performance:
```
make calib
```
